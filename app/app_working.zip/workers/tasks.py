from app.workers.celery_worker import celery
from app.services.face_service import process_event_images
from app.database.db import SessionLocal
from app.models.cluster import Cluster
from app.models.event import Event
from app.services.faiss_manager import FaissManager
from app.core.config import INDEXES_PATH, STORAGE_PATH
from app.services.image_pipeline import process_raw_image

from datetime import datetime
import shutil
import pickle
import os


# ======================================================
# MAIN PROCESSING TASK
# ======================================================

@celery.task
def process_images(event_id: int):

    db = SessionLocal()
    event = None

    try:
        event = db.query(Event).filter(Event.id == event_id).first()

        if not event:
            return {"status": "event_not_found"}

        # -------------------------
        # 1️⃣ INITIAL STATUS UPDATE
        # -------------------------
        event.processing_status = "processing"
        event.processing_started_at = datetime.utcnow()
        event.processing_progress = 5
        db.commit()

        folder = os.path.join(STORAGE_PATH, str(event_id))

        raw_files = [
            f for f in os.listdir(folder)
            if f.startswith("raw_")
        ]

        total_files = len(raw_files)

        # -------------------------
        # 2️⃣ IMAGE OPTIMIZATION
        # -------------------------
        for idx, raw_file in enumerate(raw_files):

            raw_path = os.path.join(folder, raw_file)

            optimized_name = process_raw_image(raw_path, folder)

            os.remove(raw_path)

            if total_files > 0:
                progress = 10 + int(((idx + 1) / total_files) * 40)
                event.processing_progress = progress
                db.commit()

        # -------------------------
        # 3️⃣ FACE DETECTION + EMBEDDINGS
        # -------------------------
        faces = process_event_images(event_id)

        # -------------------------
        # 4️⃣ RESET CLUSTERS + FAISS
        # -------------------------
        db.query(Cluster).filter(
            Cluster.event_id == event_id
        ).delete()
        db.commit()

        # Remove old FAISS instance from memory
        FaissManager.remove_index(event_id)

        # Get fresh FAISS index instance (managed)
        faiss_index = FaissManager.get_index(event_id)

        clusters = []
        embeddings = []

        for idx, (image_name, embedding) in enumerate(faces):

            cluster = Cluster(
                event_id=event_id,
                cluster_id=idx,
                image_name=image_name,
                embedding=pickle.dumps(embedding)
            )

            clusters.append(cluster)
            embeddings.append(embedding)

        if clusters:
            db.add_all(clusters)
            db.commit()

        ids = [c.id for c in clusters]

        # Add embeddings to FAISS
        if embeddings:
            faiss_index.add_embeddings(embeddings, ids)

        # -------------------------
        # 5️⃣ FINAL UPDATE
        # -------------------------
        event.total_faces = len(embeddings)
        event.total_clusters = len(embeddings)
        event.processing_status = "completed"
        event.processing_progress = 100
        event.processing_completed_at = datetime.utcnow()

        db.commit()

        print(f"✅ Event {event_id} indexing completed. FAISS size: {faiss_index.index.ntotal}")

        return {"status": "completed"}

    except Exception as e:

        db.rollback()

        if event:
            event.processing_status = "failed"
            event.processing_progress = 0
            db.commit()

        print("❌ Processing error:", str(e))
        raise e

    finally:
        db.close()


# ======================================================
# CLEANUP TASK
# ======================================================

@celery.task
def cleanup_expired_events():

    db = SessionLocal()

    try:
        now = datetime.utcnow()

        expired_events = db.query(Event).filter(
            Event.expires_at != None,
            Event.expires_at < now
        ).all()

        for event in expired_events:

            print(f"🗑 Cleaning expired event {event.id}")

            # Remove clusters
            db.query(Cluster).filter(
                Cluster.event_id == event.id
            ).delete()

            # Remove FAISS from memory
            FaissManager.remove_index(event.id)

            # Remove FAISS files
            index_path = os.path.join(
                INDEXES_PATH,
                f"event_{event.id}.index"
            )

            map_path = os.path.join(
                INDEXES_PATH,
                f"event_{event.id}_map.npy"
            )

            if os.path.exists(index_path):
                os.remove(index_path)

            if os.path.exists(map_path):
                os.remove(map_path)

            # Remove storage folder
            event_folder = os.path.join(
                STORAGE_PATH,
                str(event.id)
            )

            if os.path.exists(event_folder):
                shutil.rmtree(event_folder)

            db.delete(event)

        db.commit()
        print("✅ Expired events cleanup completed")

    except Exception as e:
        db.rollback()
        print("❌ Cleanup error:", str(e))
        raise e

    finally:
        db.close()
