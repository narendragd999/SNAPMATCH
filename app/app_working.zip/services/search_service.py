import numpy as np
import cv2
from sqlalchemy.orm import Session
from app.models.cluster import Cluster
from app.services.faiss_manager import FaissManager
from app.services.face_model import face_app


SIMILARITY_THRESHOLD = 0.52
MAX_RESULTS = 50
MAX_DIM = 800


# --------------------------------------------------
# Extract ALL face embeddings (Important Fix)
# --------------------------------------------------
def extract_all_embeddings(image_bytes: bytes):

    np_arr = np.frombuffer(image_bytes, np.uint8)
    img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

    if img is None:
        return []

    # Same resize logic as indexing
    h, w = img.shape[:2]
    if max(h, w) > MAX_DIM:
        scale = MAX_DIM / max(h, w)
        img = cv2.resize(
            img,
            (int(w * scale), int(h * scale)),
            interpolation=cv2.INTER_AREA
        )

    faces = face_app.get(img)

    embeddings = []

    for face in faces:
        emb = face.embedding
        norm = np.linalg.norm(emb)
        if norm == 0:
            continue
        embeddings.append(emb / norm)

    return embeddings


# --------------------------------------------------
# PUBLIC SEARCH (Clean & Stable Version)
# --------------------------------------------------
async def public_search_face(event_id: int, file, db: Session):

    contents = await file.read()

    embeddings = extract_all_embeddings(contents)

    if not embeddings:
        return {"error": "No face detected"}

    faiss_index = FaissManager.get_index(event_id)

    matched_images_dict = {}
    matched_cluster_ids = set()

    # ------------------------------
    # 1️⃣ Search for all faces
    # ------------------------------
    for embedding in embeddings:

        results = faiss_index.search(embedding, MAX_RESULTS)

        for item in results:
            print("Score:", item["score"])
            if item["score"] < SIMILARITY_THRESHOLD:
                continue

            cluster = db.query(Cluster).filter(
                Cluster.id == item["db_id"]
            ).first()

            if not cluster:
                continue

            image_name = cluster.image_name

            # Keep best similarity per image
            if (
                image_name not in matched_images_dict
                or item["score"] > matched_images_dict[image_name]["similarity"]
            ):
                matched_images_dict[image_name] = {
                    "image_name": image_name,
                    "cluster_id": cluster.cluster_id,
                    "similarity": round(item["score"], 4)
                }

            matched_cluster_ids.add(cluster.cluster_id)

    if not matched_images_dict:
        return {
            "matched_photos": [],
            "friends_photos": [],
            "matched_cluster_ids": []
        }

    # ------------------------------
    # 2️⃣ Find user images
    # ------------------------------
    user_images = set(matched_images_dict.keys())

    # ------------------------------
    # 3️⃣ Find friend images
    # ------------------------------
    friend_images = set()

    for image_name in user_images:

        rows = db.query(Cluster).filter(
            Cluster.event_id == event_id,
            Cluster.image_name == image_name
        ).all()

        for r in rows:
            if r.cluster_id not in matched_cluster_ids:
                friend_images.add(image_name)

    friend_images = list(friend_images)

    # ------------------------------
    # 4️⃣ Clean separation
    # ------------------------------
    matched_photos = [
        v for v in matched_images_dict.values()
        if v["image_name"] not in friend_images
    ]

    return {
        "matched_photos": matched_photos,
        "friends_photos": friend_images,
        "matched_cluster_ids": list(matched_cluster_ids)
    }


# --------------------------------------------------
# OWNER SEARCH
# --------------------------------------------------
async def search_face(event_id: int, file, db: Session):

    contents = await file.read()

    embeddings = extract_all_embeddings(contents)

    if not embeddings:
        return {"error": "No face detected"}

    faiss_index = FaissManager.get_index(event_id)

    final_results = {}

    for embedding in embeddings:

        results = faiss_index.search(embedding, MAX_RESULTS)

        for item in results:

            if item["score"] < SIMILARITY_THRESHOLD:
                continue

            cluster = db.query(Cluster).filter(
                Cluster.id == item["db_id"]
            ).first()

            if not cluster:
                continue

            image_name = cluster.image_name

            if (
                image_name not in final_results
                or item["score"] > final_results[image_name]["similarity"]
            ):
                final_results[image_name] = {
                    "image_name": image_name,
                    "cluster_id": cluster.cluster_id,
                    "similarity": round(item["score"], 4)
                }

    return {
        "total_matches": len(final_results),
        "matches": list(final_results.values())
    }
