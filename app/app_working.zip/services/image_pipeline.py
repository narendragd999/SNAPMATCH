import os
import uuid
from PIL import Image

MAX_SIZE = 1200
THUMB_SIZE = 400
JPEG_QUALITY = 85
WEBP_QUALITY = 80


def process_raw_image(raw_path: str, event_folder: str):

    #print("🔥🔥🔥 process_raw_image EXECUTED 🔥🔥🔥")

    os.makedirs(event_folder, exist_ok=True)
    thumb_folder = os.path.join(event_folder, "thumbnails")
    os.makedirs(thumb_folder, exist_ok=True)

    base_name = str(uuid.uuid4())

    jpeg_path = os.path.join(event_folder, f"{base_name}.jpg")
    webp_path = os.path.join(event_folder, f"{base_name}.webp")
    thumb_path = os.path.join(thumb_folder, f"{base_name}.webp")

    with Image.open(raw_path) as img:

        img = img.convert("RGB")

        width, height = img.size

        # Resize if needed
        if max(width, height) > MAX_SIZE:
            img.thumbnail((MAX_SIZE, MAX_SIZE), Image.LANCZOS)

        # Save optimized JPEG
        img.save(
            jpeg_path,
            "JPEG",
            quality=JPEG_QUALITY,
            optimize=True,
            progressive=True
        )

        # Save WebP
        # img.save(
        #     webp_path,
        #     "WEBP",
        #     quality=WEBP_QUALITY,
        #     method=3
        # )

        # Generate thumbnail
        thumb = img.copy()
        thumb.thumbnail((THUMB_SIZE, THUMB_SIZE), Image.LANCZOS)

        thumb.save(
            thumb_path,
            "WEBP",
            quality=75,
            method=3
        )

    return f"{base_name}.jpg"
